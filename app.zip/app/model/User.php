<?php

class User
{
    protected $errors =[];
    protected $table ="users";
    public function validate() {

       
if(empty($this->errors)){

    $this->errors =[];
    return true;
}
        return false;
    }

    
    
}