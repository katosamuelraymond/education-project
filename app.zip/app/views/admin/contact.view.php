<?php 
$data['pageTitle'] = "Contact - incredible education platform";
$this->view('admin/includes/admin.head',$data);


$this->view('admin/includes/admin.header',$data);
$this->view('admin/admin.aside',$data);

?>



<?=$this->view('admin/includes/admin.footer',$data);?>
<?php $this->view('admin/includes/admin.scripts',$data) ?>
