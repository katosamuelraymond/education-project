<script src="<?=ROOT?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=ROOT?>/assets/js/admin.js"></script>
  

</body>
</html>