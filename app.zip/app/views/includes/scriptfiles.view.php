<script src="<?=ROOT?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="<?=ROOT?>/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?=ROOT?>/assets/vendor/swiper/swiper-bundle.min.js"></script>

  
    <script src="<?=ROOT?>/assets/js/main.js"></script>
</body>
</html>
