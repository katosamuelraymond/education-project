

<header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container position-relative d-flex align-items-center justify-content-between">

        <a href="<?=ROOT?>" class="logo d-flex align-items-center me-auto me-xl-0">
           
            <img src="<?=ROOT?>/assets/img/logo.png" alt="">
            <h1 class="sitename fs-sm-6 "><?=APPNAME?></h1>

        </a>


        <?php $this->view("includes/nav") ?>

        <div class="header-social-links">
            <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>

    </div>
</header>
