<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      
        <div class="navbar-text text-light ms-auto">
            <span class="text-center">Unlock Your Full Potential with Our Comprehensive Learning Platform. Start Your Journey Today!</span>
        </div>

    
        <div class="ms-auto">
            <a class="btn btn-primary" href="<?=ROOT?>/login">Login</a>
        </div>
    </div>
</nav>
